/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BD;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    private static Connection conn;
    
    private static final String driver = "com.mysql.jdbc.Driver";
    private static final String Usuario = "root";
    private static final String contraseña = "";
    private static final String URL = "jdbc:mysql://localhost:3306/carrosBD";


 public Conexion() {
        conn = null;
        try{
           Class.forName(driver);
           conn = (Connection) DriverManager.getConnection(URL, Usuario,contraseña);
           if(conn != null){
               System.out.println("Conexion establecida");
           }
        
        } catch(ClassNotFoundException | SQLException e){
            System.out.println("error al conectar"+ e);
        }
    }
  //nos retorna la conexion
    public Connection getConnection(){
        return conn;
    }
    
    //nos conectamos a la base de datos
    public void desconectar(){
        conn = null;
        if(conn == null){
            System.out.println("conexion terminada");
        }
}
   
    }
